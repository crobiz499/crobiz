export default defineEventHandler((event) => {
  setHeader(event, 'content-type', 'application/xml; charset=UTF-8')
  const base = 'https://www.crobiz.cz'
  const pages = ['', 'about', 'services', 'why-croatia', 'faq', 'blog', 'contact', 'privacy', 'cookies']
  const posts = ['buying-property', 'starting-company', 'living-croatia', 'tourism-rental', 'insurance-croatia', 'czech-croatian-business']
  const urls = [
    ...pages.map((path) => `${base}/${path}`),
    ...posts.map((path) => `${base}/blog/${path}`),
    ...['hr', 'en'].flatMap((locale) => [
      ...pages.map((path) => `${base}/${locale}/${path}`),
      ...posts.map((path) => `${base}/${locale}/blog/${path}`),
    ]),
  ]
  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map((url) => `  <url><loc>${url.replace(/\/$/, '') || base}</loc><changefreq>monthly</changefreq></url>`).join('\n')}
</urlset>`
})
