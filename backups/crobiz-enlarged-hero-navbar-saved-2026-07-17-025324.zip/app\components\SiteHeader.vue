<script setup>
const { t, locale, locales } = useI18n()
const localePath = useLocalePath()
const switchLocalePath = useSwitchLocalePath()
const route = useRoute()
const mobileOpen = ref(false)
const scrolled = ref(false)

const nav = computed(() => [
  ['home', '/'], ['about', '/about'], ['services', '/services'], ['why', '/why-croatia'],
  ['faq', '/faq'], ['blog', '/blog'], ['contact', '/contact'],
])

const close = () => { mobileOpen.value = false }
const changeLanguage = async (event) => {
  const path = switchLocalePath(event.target.value)
  if (path) await navigateTo(path)
}
const onScroll = () => { scrolled.value = window.scrollY > 16 }
const onKey = (event) => { if (event.key === 'Escape') close() }

watch(() => route.fullPath, close)
watch(mobileOpen, (open) => { if (import.meta.client) document.body.classList.toggle('menu-open', open) })
onMounted(() => { onScroll(); window.addEventListener('scroll', onScroll, { passive:true }); window.addEventListener('keydown', onKey) })
onBeforeUnmount(() => { window.removeEventListener('scroll', onScroll); window.removeEventListener('keydown', onKey); document.body.classList.remove('menu-open') })
</script>

<template>
  <header class="site-header" :class="{ 'is-scrolled': scrolled, 'menu-is-open': mobileOpen }">
    <a class="skip-link" href="#main-content">Skip to content</a>
    <nav class="header-inner container" :aria-label="t('nav.home')">
      <NuxtLink class="header-brand" :to="localePath('/')" :aria-label="`CROBIZ · ${t('nav.home')}`"><BrandMark compact /></NuxtLink>
      <div class="desktop-nav">
        <NuxtLink v-for="item in nav" :key="item[0]" :to="localePath(item[1])">{{ t(`nav.${item[0]}`) }}</NuxtLink>
      </div>
      <div class="header-actions">
        <label class="language-select">
          <span class="sr-only">{{ t('common.language') }}</span>
          <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.4 2.5 3.6 5.5 3.6 9S14.4 18.5 12 21M12 3C9.6 5.5 8.4 8.5 8.4 12S9.6 18.5 12 21"/></svg>
          <select :value="locale" @change="changeLanguage"><option v-for="item in locales" :key="item.code" :value="item.code">{{ item.code.toUpperCase() }}</option></select>
        </label>
        <NuxtLink class="header-cta" :to="localePath('/contact')">{{ t('actions.consultation') }}</NuxtLink>
        <button class="menu-button" type="button" :aria-expanded="mobileOpen" aria-controls="mobile-menu" :aria-label="mobileOpen ? t('common.close') : t('common.menu')" @click="mobileOpen = !mobileOpen">
          <span :class="{ open:mobileOpen }"><i/><i/><i/></span>
        </button>
      </div>
    </nav>
    <Transition name="mobile-menu">
      <div v-if="mobileOpen" id="mobile-menu" class="mobile-panel">
        <nav class="mobile-nav container">
          <NuxtLink v-for="item in nav" :key="item[0]" :to="localePath(item[1])"><span>{{ t(`nav.${item[0]}`) }}</span><span>→</span></NuxtLink>
          <NuxtLink class="button button--primary" :to="localePath('/contact')">{{ t('actions.consultation') }}</NuxtLink>
        </nav>
      </div>
    </Transition>
  </header>
</template>
