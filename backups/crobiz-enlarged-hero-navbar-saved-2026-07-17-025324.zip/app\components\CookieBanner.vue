<script setup>
const { t } = useI18n()
const visible = ref(false)
onMounted(() => { visible.value = !localStorage.getItem('crobiz-cookie-choice') })
const choose = (value) => { localStorage.setItem('crobiz-cookie-choice', value); visible.value = false }
</script>

<template>
  <Transition name="cookie">
    <aside v-if="visible" class="cookie-banner" aria-live="polite">
      <div><strong>{{ t('cookie.title') }}</strong><p>{{ t('cookie.text') }}</p></div>
      <div class="cookie-actions"><button class="button button--outline button--small" @click="choose('essential')">{{ t('cookie.essential') }}</button><button class="button button--primary button--small" @click="choose('all')">{{ t('cookie.accept') }}</button></div>
    </aside>
  </Transition>
</template>
